export class EnquiryModel {

    customerId : number;
    firstName : string;
    lastName : string;
    age : number;
    emailId : string;
    mobileNumber : number;
    adharNumber : number;
    panCardNumber : number;
    
}
