import { EnquiryModel } from './enquiry-model';

describe('EnquiryModel', () => {
  it('should create an instance', () => {
    expect(new EnquiryModel()).toBeTruthy();
  });
});
