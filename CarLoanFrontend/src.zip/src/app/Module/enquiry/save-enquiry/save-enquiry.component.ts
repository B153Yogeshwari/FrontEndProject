import { Component } from '@angular/core';

@Component({
  selector: 'app-save-enquiry',
  templateUrl: './save-enquiry.component.html',
  styleUrls: ['./save-enquiry.component.css']
})
export class SaveEnquiryComponent {

}
